class Factorial
{
    public static void main(String[] a){
        num = 10 + (12 * 18);
    }
}
