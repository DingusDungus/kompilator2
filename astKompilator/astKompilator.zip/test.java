class BigBoyClass
{
   public static void main(String[] args)
   {
      cum = 5;
   }
}

class testClass
{
   int var1;
   public int testMethod(int param1, boolean param2)
   {
      return 5;
   }
}

